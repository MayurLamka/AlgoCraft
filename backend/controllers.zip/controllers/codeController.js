const {
    runCpp
} = require("../services/codeRunner");

const {
    judgeCode
} = require("../services/judgeService");


// =====================================================
// RUN CODE
// =====================================================

const runCode = async (
    req,
    res
) => {

    try {

        const {
            questionId,
            language,
            code,
            input
        } = req.body;


        // =============================================
        // VALIDATION
        // =============================================

        if (
            !questionId ||
            !language ||
            !code
        ) {

            return res.status(400).json({

                success: false,

                message:
                    "questionId, language and code are required"
            });
        }


        // =============================================
        // CURRENTLY SUPPORT C++
        // =============================================

        if (
            language.toLowerCase() !== "cpp"
        ) {

            return res.status(400).json({

                success: false,

                message:
                    "Only C++ is currently supported"
            });
        }


        // =============================================
        // RUN USER CODE
        // =============================================

        const execution =
            await runCpp(
                code,
                input || ""
            );


        return res.status(200).json({

            success:
                execution.success,

            status:
                execution.status,

            output:
                execution.output || "",

            error:
                execution.error || ""
        });


    } catch (error) {

        console.error(
            "RUN CODE ERROR:",
            error
        );


        return res.status(500).json({

            success: false,

            message:
                "Code execution failed",

            error:
                error.message
        });
    }
};


// =====================================================
// SUBMIT CODE
// =====================================================

const submitCode = async (
    req,
    res
) => {

    try {

        const {
            questionId,
            language,
            code
        } = req.body;


        // =============================================
        // VALIDATION
        // =============================================

        if (
            !questionId ||
            !language ||
            !code
        ) {

            return res.status(400).json({

                success: false,

                message:
                    "questionId, language and code are required"
            });
        }


        // =============================================
        // CURRENTLY SUPPORT C++
        // =============================================

        if (
            language.toLowerCase() !== "cpp"
        ) {

            return res.status(400).json({

                success: false,

                message:
                    "Only C++ is currently supported"
            });
        }


        // =============================================
        // JUDGE
        // =============================================

        const result =
            await judgeCode(
                code,
                questionId
            );


        return res.status(200).json(
            result
        );


    } catch (error) {

        console.error(
            "SUBMIT CODE ERROR:",
            error
        );


        return res.status(500).json({

            success: false,

            message:
                "Submission failed",

            error:
                error.message
        });
    }
};


module.exports = {

    runCode,

    submitCode
};